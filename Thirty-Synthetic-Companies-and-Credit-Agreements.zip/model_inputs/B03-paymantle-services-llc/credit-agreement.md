# PayMantle Services, LLC Senior Secured Credit Agreement

Agreement B03-CA-2026-01, version 1.0. Synthetic execution, effective and known-at date: December 31, 2026. All entities, terms and events are fictional and operative only within this simulation. This is an individually selected contract, not a menu of unelected clauses. No real signature or practitioner validation is represented.

## Parties and financing terms

PayMantle Services, LLC (Borrower), a Delaware entity, and Blue Quarry Capital LLC (sole Lender and collateral beneficiary) enter into the following simulated agreement. Juniper Crown Equity controls Borrower but provides no funding guarantee. The two subsidiaries named in the definitions are guarantors and collateral grantors.

Lender advances $88.000m at par on December 31, 2026, solely to refinance equal-principal predecessor operating-company debt. Sources and uses are equal; no incremental operating cash, closing fee or original-issue discount is assumed. Interest is fixed at 10.00% per annum, actual days/365, on outstanding principal, payable each March 31, June 30, September 30 and December 31 beginning March 31, 2027. No PIK election, revolver or further commitment exists. Scheduled principal is $1.760m each December 31 from 2027 through 2030; the remaining $80.960m falls due on 2031-12-31. Voluntary prepayment at par is permitted on three Business Days' notice with accrued interest; it reduces the final balloon before scheduled installments and creates no reborrowing right. No prepayment premium or default-rate increase is imposed.

The collateral package is first-priority security over Loan Party beneficial assets, subject only to C03 permitted liens and the express exclusion of third-party client funds. Executed guarantees/security, required UCC and applicable IP filings, control over Eligible Cash accounts, evidence of borrower authorization and permitted insurance, and a signed opening Debt/cash/EBITDA schedule are closing conditions. The simulation assumes these conditions satisfied; filing jurisdictions and executed instruments must accompany a real documentary evaluation of perfection. There are no undisclosed post-closing deliverables or assumed third-party guarantees.

## Business and opening schedules

PayMantle provides payroll processing, employment-tax filing, and workforce payment software to multi-state service businesses under recurring per-employee contracts. Its principal operating risk is timely segregation and transmission of client payroll and tax funds across changing jurisdictional calendars.

| Closing financial schedule | USD millions |
| --- | ---: |
| Revenue | 110.000 |
| Reported EBITDA | 24.000 |
| Documented permitted restructuring adjustment | 0.800 |
| Covenant EBITDA | 24.800 |
| Opening term Debt | 88.000 |
| Eligible operating cash | 14.000 |
| Restricted/client cash excluded | 7.000 |

Ownership: Borrower owns 100% of each named subsidiary; the sponsor controls Borrower. Debt schedule: this facility only. Permitted existing liens: lender security only. Restricted funds of $7.000m are client-owned custodial balances with an equal segregated-funds obligation, expressly outside lender collateral; they are excluded from repayment resources and receive no netting benefit. The financial model separately reconciles assets, liabilities, equity, earnings and cash movements; that model's projections do not modify this contract.

## Definitions and conventions

**Group and Loan Parties.** Borrower and its two wholly owned domestic subsidiaries, PayMantle Tax Services, Inc. and PayMantle Workforce Payments, LLC, are the only opening Group members and Loan Parties. Both subsidiaries guarantee all facility obligations. Consolidate and eliminate intercompany balances. Newly controlled subsidiaries consolidate immediately, even before guarantee accession. No unrestricted subsidiaries, outside guarantees or opening lease Debt exist. Control means power to direct management through voting rights, contract or otherwise; affiliate means control or common control. Lender security covers only Loan Party beneficial property; third-party client or custodial funds are expressly excluded from collateral, lender-benefit deposit control and operating resources.

**Permitted Business and Core IP.** Permitted Business is payroll and employment-tax software and activities reasonably related to delivering the products and services described in the business schedule below. Relatedness depends on actual customers, products, capabilities and operating resources. Core IP is source code, operating documentation, proprietary datasets, marks and rights essential to that business. Material Collateral is any asset necessary to continue core service delivery, or other assets with aggregate fair value over $0.500m. These definitions do not turn business forecasts into covenants.

**Debt and Cash.** Debt includes funded borrowings, finance-lease principal, capitalized PIK, unreimbursed letter-of-credit drawings and funded guarantee obligations currently payable, without consolidated double counting. Exclude ordinary non-interest-bearing trade payables and operating leases. Permission to incur remains governed by C03. Eligible Cash is unrestricted USD cash owned by a Loan Party in a U.S. bank account, immediately accessible for debt service and subject to no security other than the lender's. Exclude client, trust, escrow, restricted, blocked and foreign-subsidiary cash. Leverage netting is capped at $12.000m and Debt; transaction tests also exclude unspent proceeds of the Debt being incurred. A cash minimum, if elected, is uncapped.

**Earnings and investment.** Reported EBITDA is consolidated U.S. GAAP net income plus interest expense, income-tax expense, depreciation and amortization. Covenant EBITDA adds only documented cash restructuring costs deducted in Reported EBITDA, capped at 5% of positive Reported EBITDA, and subtracts included nonoperating disposal gains. There are no forecast-synergy, stock-compensation, ordinary recurring-cost or other adjustments. Research costs follow GAAP; qualifying capitalized software development is amortized over three years when available for use. Capital Investment includes all cash equipment and capitalized development spending once, excluding acquisition consideration and already-expensed items. Reconcile policy changes to the closing basis. The closing adjustment is $0.800m; its supporting restructuring expense is already in Reported EBITDA and must not be deducted twice in cash flow.

**Testing and pro forma calculations.** Quarter-end Debt/cash uses that date; earnings use the four then-ended fiscal quarters. No automatic annualization. For a proposed transaction, adjust debt/cash and historical earnings for the complete transaction and related steps, using verified target earnings for the same four-quarter period, eliminating overlap and disposed earnings. No forecast savings. Missing inputs mean permission is unestablished, not presumed. Compare unrounded values; displayed figures are rounded only for readability.

**Calendar and delivery.** New York time; Business Days exclude weekends and observed U.S. federal holidays. Exclude the triggering day. Calendar-day delivery and post-closing administrative-performance deadlines roll forward to the next Business Day; measurements do not. Delivery requires the lender's designated reporting portal timestamp by 5 p.m.; later receipts count on the next Business Day. Contractual interest and principal dates do not roll: if not a Business Day, prefund lender by the preceding Business Day for credit on the contractual date, with no interest extension. The financial schedules model the contractual credit date; prefunded amounts are unavailable cash until applied.

**Consent and baskets.** All amendments and waivers require a written instrument signed by the sole lender and Borrower, identifying affected terms/periods, effective date and conditions. Prior transaction consent requires the lender's written approval before execution. No-default conditions apply only where stated and include unremedied failures during a grace period. Annual baskets reset January 1; no carryforward, reclassification, replenishment or splitting unless expressly allowed. Outstanding baskets free capacity only upon actual principal repayment. An internal budget, unsigned draft or sponsor funding intention is not consent or received cash.

## Covenants

### C01 Maximum total net leverage

PayMantle Services, LLC shall not permit Total Net Leverage to exceed 3.95x at any calendar quarter-end beginning March 31, 2027. The numerator is consolidated Debt less min(Eligible Cash, $12.000m, Debt); the denominator is Covenant EBITDA for the four quarters ending on that date. This is a maintenance test independent of borrowing activity. Equality passes, full precision governs, and no stepdown or automatic equity cure is granted. Positive Net Debt with nonpositive Covenant EBITDA fails; zero Net Debt is defined as zero leverage for this simulation.

Evidence required: Debt register, qualified cash balances, trailing-four-quarter EBITDA bridge and adjustment support. Resolution category: F.

### C02 Financial reporting and compliance certification

Borrower shall deliver consolidated quarterly balance sheets, income statements and cash-flow statements and an officer-signed covenant certificate within 30 calendar days after each quarter-end, beginning March 31, 2027. Include debt/cash reconciliations, adjustment evidence, policy changes, actual annual and outstanding basket usage, and every elected test. Fourth-quarter management reporting is still required. Annual audited statements and the auditor's report are due within 90 calendar days after year-end, first December 31, 2027; an audit qualification must be disclosed but is not alone a delivery breach. A board-approved monthly annual budget and cash forecast are due within 30 calendar days after each year begins, first 2027. If maturity falls within 18 months, include a documented maturity funding plan. A certificate disclosing failure can satisfy delivery; missing evidence does not establish a ratio failure.

Evidence required: Statements, signed certificates, support schedules, audit/budget approvals and portal receipt timestamps. Resolution category: R.

### C03 Debt and lien limitations

The Group shall incur no Debt or third-party guarantee except this facility and Loan Party guarantees, and finance leases not exceeding $1.400m principal outstanding in aggregate. A new lease requires no continuing Default and pro forma leverage no greater than 3.60x. Actual principal repayment releases that outstanding basket; no annual reset applies. Lease security is limited to the financed asset. Other permitted liens are lender security and ordinary statutory liens not overdue or contested in good faith with GAAP reserves and a collection stay protecting Material Collateral. Other financing, PIK, seller notes, earnouts and letters of credit require prior written consent and an amendment defining treatment; no independent unfunded-guarantee basket exists. Voluntarily unauthorized Debt/liens use X; a remediable statutory-lien qualification failure uses A.

Evidence required: Financing instruments, guarantee register, lease balances and asset schedule, lien searches and contest evidence. Resolution category: X / A.

### C04 Distributions and sponsor leakage

Cash dividends to persons outside the Loan Party group shall not exceed $1.000m in aggregate per calendar fiscal year and require no continuing Default, pro forma leverage no greater than 3.40x and at least $8.000m Eligible Cash after payment. No unused capacity carries forward or replenishes after repayment. Equity redemptions, sponsor monitoring fees, and voluntary junior-debt repayments require prior written consent and have no independent basket. Transfers among Loan Parties preserving security do not use the dividend basket. Ordinary employee compensation and payment for documented arm's-length operating services are not dividends, but payments to sponsor affiliates above $0.250m annually require disinterested board approval and pricing support.

Evidence required: Executed payment evidence, recipient/control identity, annual usage, fair-pricing support and post-payment cash/leverage. Resolution category: X.

### C05 Acquisitions and investments

Acquisitions within the Permitted Business may be made for aggregate cash consideration including fees not exceeding $4.000m per fiscal year, only with no continuing Default, pro forma leverage at or below 3.60x, and at least $8.000m post-closing Eligible Cash. No carryforward, replenishment or transaction splitting is permitted. Historical target earnings must be verified under the same EBITDA definition; assumed Debt separately needs C03 permission. Contingent consideration and seller financing need prior consent. Other investments require prior written consent except ordinary bank deposits, trade receivables, and transfers between Loan Parties preserving security. An acquired subsidiary consolidates at control acquisition and must accede under C07; its cash is not Eligible Cash until it qualifies as a Loan Party. A proposal that has not closed is not an executed breach.

Evidence required: Signed purchase/investment documents, related consideration, financing, historical target financials, group chart and accession records. Resolution category: X.

### C06 Business scope and asset protection

The Group shall remain within the Permitted Business and may sell obsolete equipment at fair value only up to $0.500m aggregate fair value per fiscal year, without carryforward or recycling. No receivables sale, material operating asset transfer, ownership transfer or exclusive license of Core IP outside the Loan Party group is permitted without prior written consent. Nonexclusive ordinary customer-use licenses and transfers between Loan Parties preserving security are permitted. Sale receipts must be paid to a Loan Party and may then fund ordinary operations, independently permitted transactions or Debt repayment; there is no additional proceeds sweep. A change in customer cancellation rights or permitted revenue mix is not automatically a business-scope breach. The sector-specific S clauses apply independently.

Evidence required: Executed asset/IP documents, rights conveyed, fair values, business activities, recipient identity, annual usage and proceeds. Resolution category: X.

### C07 Existence insurance guarantees and collateral

Loan Parties shall preserve existence, maintain books and required operating assets, and pay taxes when due except amounts contested in good faith with GAAP reserves and a stay against sale of Material Collateral. Maintain property coverage at replacement cost for tangible Material Collateral, general liability of $2m per occurrence/$4m aggregate, and technology or professional liability plus cyber coverage of $5m aggregate per policy year, with deductibles no greater than $0.250m; lender shall be loss payee or additional insured where applicable. Renewal certificates are due five Business Days after renewal (R); restoring coverage remedies a lapse prospectively under A, preserving its history and uninsured losses. New domestic subsidiaries must guarantee the facility and deliver security accessions within ten Business Days of control acquisition, and complete perfection on existing assets and equity within 30 calendar days of that date. Other uncovered newly acquired assets require executed instruments within fifteen Business Days and perfection within 30 calendar days. Foreign subsidiaries, unrestricted designations and reorganizations outside a merger into a surviving Loan Party preserving guarantees/security require prior consent (X). Permit relevant lender inspection on five Business Days' notice, at borrower expense twice annually absent Default (R).

Evidence required: Entity records, policies and endorsements, tax contest/stay, signed guarantees, actual filings/control evidence and access requests. Resolution category: A / R / X.

### C08 Default and material customer notices

Within five Business Days of the earliest actual knowledge of the CEO, CFO or general counsel, Borrower shall notify lender of any contractual noncompliance and of an actual written termination or nonrenewal notice from a customer group accounting for at least 20% of prior fiscal-year consolidated revenue. Aggregate customer affiliates under common control at receipt, counting revenue once. Include facts, knowledge and effective dates, exposure, and proposed mitigation. An executed grant of a cancellation right without an actual termination/nonrenewal notice does not alone trigger the customer-notice limb. Reporting does not cure another covenant. More specific notices under S1–S3 remain independently applicable.

Evidence required: Actual underlying notice/event, officer knowledge evidence, customer-group revenue, delivered lender notice and timestamp. Resolution category: R.

### C09 Minimum cash debt-service coverage

At each quarter-end beginning December 31, 2027, Cash Debt-Service Coverage shall be at least 1.25x. Its numerator is trailing-four-quarter Reported EBITDA less cash income taxes paid, cash Capital Investment, and positive operating working-capital investment, counted once. Its denominator is cash interest paid or contractually payable for that period, including overdue interest, plus principal scheduled to fall due in the period, including finance-lease principal. Exclude voluntary principal payments and the final term-loan balloon. Operating working capital is trade receivables plus unbilled contract assets and prepaid operating expenses less trade payables and operating accruals; exclude cash, Debt, interest and taxes. Releases give no numerator uplift. If the denominator is zero, require a nonnegative numerator. Equality passes; the excluded balloon needs a separate funding plan.

Evidence required: Same-period financial, debt-service and investment schedules reconciled to the signed certificate; actual spending dates for a capital limit. Resolution category: F.

### S1 Client-fund segregation and remittance

From closing, the Borrower shall hold all collected client payroll and employment-tax funds in accounts designated for client obligations and shall not treat those balances as Eligible Cash. It shall transmit payroll and tax amounts by the applicable contractual or statutory deadline. Within one Business Day after a responsible treasury officer learns of a missed transmission affecting more than 1% of a processing day's aggregate client obligations, the Borrower shall notify the Lender and affected clients, fund any Borrower-caused deficiency, and begin documented remediation. A bank-network failure is excepted only while the Borrower uses its established alternate payment channel and completes transmission promptly after restoration.

Evidence required: Designated-account statements, daily funding reconciliation, payment confirmations, statutory calendar, officer knowledge record, client notices, and alternate-channel logs. Resolution category: A.

### S2 Jurisdiction filing-calendar control

The Borrower shall maintain an effective-date calendar for payroll-tax filing and deposit requirements in every jurisdiction serving active clients. A compliance officer shall approve each material calendar change before it reaches production and retain the official source, configuration ticket, test result, and deployment date. Within 20 calendar days after each quarter-end, first March 31, 2027, the Borrower shall deliver a schedule of changes, overdue configurations, and related filing exceptions. A jurisdiction newly entered through a customer launch may be added within ten Business Days after the first processed payroll if interim filing responsibility remains contractually with the customer.

Evidence required: Official jurisdiction notices, approved calendar, configuration tickets, test results, deployment log, customer launch terms, and quarterly exception schedule. Resolution category: R.

### S3 Payroll engine release protection

The Borrower shall not deploy a material payroll-calculation engine release to all production clients unless it has completed parallel calculations for at least two representative pay cycles and documented resolution of every high-severity variance. A limited pilot covering no more than 10% of active employees is permitted after one representative cycle if the release can be rolled back without altering completed payroll records. The Borrower shall retain comparison outputs, approvals, pilot scope, rollback evidence, and post-release exception monitoring for two years. Deployment contrary to this prohibition is an immediate violation when the general production release begins.

Evidence required: Release approvals, parallel-calculation outputs, variance register, pilot population, rollback test, deployment log, and post-release exception report. Resolution category: X.

## Defaults waivers and remedies

`F`: failure of a financial maximum/minimum at its measurement time is an Event of Default, without automatic numerical grace or equity cure. `R`: a missed reporting/access requirement is noncompliance when due, becoming an Event of Default only if still unremedied at the close of ten Business Days after written lender notice. `A`: a remediable affirmative failure becomes an Event of Default if still unremedied at the close of 30 calendar days after written lender notice; an expressly irremediable failure is immediate. Restoration of insurance remedies ongoing coverage, preserving the historical gap. `X`: an executed prohibited transaction without required permission is an immediate Event of Default; a proposal is not execution. Clauses with two categories apply each to the specified duty. Nonpayment of principal when due is an Event of Default; unpaid interest has three Business Days after its contractual due date. A materially false signed compliance statement is an Event of Default if knowingly false when signed; incompleteness alone is treated under the reporting duty.

While an Event of Default continues, Lender may accelerate outstanding principal and accrued interest by written declaration delivered to Borrower. A waived or timely remedied failure does not support new acceleration. Enforcement of collateral requires separate action under the governing security documents and applicable law; neither a failed ratio nor a software output itself carries out enforcement. No unrelated-agreement cross-default or subjective material-adverse-change default is added by this synthetic agreement. Apply a signed waiver only to its specified obligation, period and conditions; retain the original test and missed dates. No covenant can be inferred from an underwriting belief.

New York law governs the simulated contractual relationship, subject to applicable mandatory law and the law governing asset perfection. Notices go to the parties' designated reporting portal; administrative notices require receipt evidence. This writing and identified signed amendments are the complete operative synthetic terms. No implied basket, cure, consent, sponsor commitment or lender commitment exists outside them.

## Authoring provenance and limitations

Every number and sentence above is authored synthetic content. Structural references: framework M1 (Artivion/Ares, January 18, 2024, §6.7) for leverage and negotiated restriction structure; M3 (Evolent/Ares, December 30, 2019, §§8.01 and 9.12) for reporting and business scope; M4 (NN/Oaktree, March 28, 2025 amendment §2(c), restating §7.14(b)) only where a cash-forecast trigger is elected. S1–S3 are entirely synthetic borrower-specific provisions. See the portfolio source register for direct links and limitations. No agreement supplies market-median values for this borrower. Source-informed drafting, financial arithmetic checks and internal AI review do not establish legal enforceability or practitioner comparability.
